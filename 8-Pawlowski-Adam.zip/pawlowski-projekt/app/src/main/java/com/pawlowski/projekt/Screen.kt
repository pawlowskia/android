package com.pawlowski.projekt

sealed class Screen (val route: String){
    object Home: Screen("home")
    object Photos: Screen("photos")
    object Lista: Screen("lista")
}