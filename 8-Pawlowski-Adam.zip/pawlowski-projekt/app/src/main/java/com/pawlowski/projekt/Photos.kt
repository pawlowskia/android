package com.pawlowski.projekt

import android.content.Context
import android.widget.Space
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LiveData
import androidx.navigation.NavController
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.plcoding.m3_navigationdrawer.R
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val selectedPhoto: Int,
    val name: String,
    val nickname: String
)

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertUser(user: User)

    @Query("SELECT * FROM users")
    fun getUser(): LiveData<User?> // Using LiveData to observe changes
}

@Database(entities = [User::class], version = 1)
abstract class UserDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
}


object UserDatabaseProvider {
    private var instance: UserDatabase? = null

    fun getInstance(context: Context): UserDatabase {
        if (instance == null) {
            instance = Room.databaseBuilder(
                context.applicationContext,
                UserDatabase::class.java,
                "user_database"
            ).build()
        }
        return instance!!
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Photos(navController: NavController) {
    val context = LocalContext.current
    val userDatabase = UserDatabaseProvider.getInstance(context)
    val userDao = userDatabase.userDao()

    var v1 by remember { mutableStateOf("Adam") }
    var v2 by remember { mutableStateOf("Młody") }

    var name by remember {
        mutableStateOf("Adam")
    }
    var nickname by remember {
        mutableStateOf("Młody")
    }

    var selPhot by remember { mutableStateOf(0) }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(48.dp))
        Divider()
        selPhot = LazyImageRow()
        Divider()
        OutlinedTextField(
            value = v1,
            onValueChange = { text ->
                v1 = text
                name = v1
                            },
            label = { Text("Imię") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
        )
        OutlinedTextField(
            value = v2,
            onValueChange = { text->
                v2 = text
                nickname = v2
                            },
            label = { Text("Pseudonim") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
        )
        Button(
            onClick = {
                saveUserProfile(selPhot, name, nickname, userDao)
            },
            modifier = Modifier
                .padding(8.dp)
        ) {
            Text(text = "Zapisz")
        }
    }

}

@Composable
fun LazyImageRow() : Int {
    var selectedPhoto by rememberSaveable { mutableStateOf(0) }
    LazyRow {
        items(4) { index ->
            Column (
                modifier = Modifier
                    .padding(8.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Divider()
                Image(
                    painter = painterResource(id = getImageResId(index)),
                    contentDescription = null, // Provide a meaningful description if needed
                    modifier = Modifier
                        .padding(8.dp)
                        .scale(1f)
                )
                Divider()
                Button(
                    onClick = {
                        selectedPhoto = index
                    },

                ) {
                    Text(text = "Ustaw jako profilowe")
                }
            }
        }
    }
    return selectedPhoto
}

@OptIn(DelicateCoroutinesApi::class)
private fun saveUserProfile(selectedPhoto: Int, name: String, nickname: String, userDao: UserDao) {
    GlobalScope.launch(Dispatchers.IO) {
        println(
            "User profile to save: $name $nickname $selectedPhoto"
        )
        val user = User(selectedPhoto = selectedPhoto, name = name, nickname = nickname)
        println(
            "User profile to save: ${user.name} ${user.nickname} ${user.selectedPhoto}"
        )
        userDao.insertUser(user)
        println(
            "User profile saved: ${userDao.getUser().value?.name} ${userDao.getUser().value?.nickname} ${userDao.getUser().value?.selectedPhoto}"
        )
    }
}


@Composable
fun getImageResId(index: Int): Int {
    // Replace these placeholder resource IDs with the actual resource IDs of your images
    return when (index) {
        0 -> R.drawable.thispersondoesnotexist
        1 -> R.drawable.thispersondoesnotexist1
        2 -> R.drawable.thispersondoesnotexist2
        3 -> R.drawable.thispersondoesnotexist3
        else -> R.drawable.thispersondoesnotexist // Use a placeholder or default image if needed
    }
}

@Composable
fun Home(navController: NavController){
    Column(
//        verticalArrangement = Arrangement.Center,
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .padding(120.dp)
    ){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text(
                text = "Adam",
                fontSize = 24.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Image(
                painter = painterResource(id = R.drawable.thispersondoesnotexist),
                contentDescription = "profilowe",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()
            )
            Divider()
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Młody",
                fontSize = 24.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
        }



    }

}