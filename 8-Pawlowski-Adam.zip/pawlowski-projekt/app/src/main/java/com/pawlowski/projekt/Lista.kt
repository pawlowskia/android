package com.pawlowski.projekt

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

import androidx.room.Entity
import androidx.room.PrimaryKey

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

import androidx.room.Database
import androidx.room.RoomDatabase


import android.content.Context
import android.provider.Settings.Global
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextField
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.LiveData
import androidx.room.Room
import java.util.concurrent.Flow

import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers

import androidx.lifecycle.lifecycleScope
import androidx.room.Delete
import androidx.room.OnConflictStrategy
import com.plcoding.m3_navigationdrawer.R
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch




@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    var name: String,
    var description: String,
    var isDone: Boolean
)

@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTask(task: Task)

    @Delete
    fun deleteTask(task: Task)

    @Query("SELECT * FROM tasks")
    fun getAll(): LiveData<List<Task>>
}

@Database(entities = [Task::class], version = 1)
abstract class TaskDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
}

object DatabaseProvider {
    private var instance: TaskDatabase? = null

    fun getInstance(context: Context): TaskDatabase {
        if (instance == null) {
            instance = Room.databaseBuilder(
                context.applicationContext,
                TaskDatabase::class.java,
                "task_database"
            ).build()
        }
        return instance!!
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Lista(navController: NavController){
    var name by remember {
        mutableStateOf("")
    }
    val context = LocalContext.current
    val database = DatabaseProvider.getInstance(context)
    var task by remember {
        mutableStateOf(Task(name = "", description = "", isDone = false))
    }
    val tasksLiveData = database.taskDao().getAll()
    var tasksDB by remember {
        mutableStateOf<List<Task>>(emptyList())
    }

    LaunchedEffect(tasksLiveData) {
        val observer = Observer<List<Task>> { tasks ->
            tasksDB = tasks
        }
        tasksLiveData.observeForever(observer)
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(48.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { text ->
                    name = text
                },
                modifier = Modifier
                    .weight(1f)
            )
            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = {
                    if(name.isNotBlank()){
                        task.name = name
                        // Use coroutine to insert data
                        GlobalScope.launch(Dispatchers.IO) {
                            database.taskDao().insertTask(task)
                            task = Task(name = "", description = "", isDone = false)
                        }
                        name = ""
                    }

                }) {
                Text(text = "Dodaj")
            }
        }

        LazyColumn {
            val sortedTasks = tasksDB.sortedBy { it.isDone }


            items(sortedTasks) { currentTask ->
                var isEditing by remember { mutableStateOf(false) }
                var editedTask by remember { mutableStateOf(currentTask.copy()) }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clickable {
                            isEditing = true
                        }
                ) {
                    // if task is done, show an icon. otherwise, show a different icon
                    if (currentTask.isDone) {
                        Icon(
                            imageVector = Icons.Default.Done,
                            contentDescription = "Task is done",
                            modifier = Modifier
                                .height(24.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Task is not done",
                            modifier = Modifier
                                .height(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = currentTask.name,
                        modifier = Modifier
                            .weight(1f)
                    )
                }

                if (isEditing) {
                    EditTaskDialog(
                        editedTask = currentTask,
                        onDismiss = {
                            isEditing = false
                        },
                        onSave = {
                            // Save the changes and update the database
                            GlobalScope.launch(Dispatchers.IO) {
                                database.taskDao().insertTask(it)
                            }
                            isEditing = false
                        }
                    )
                }

                Divider()
            }

        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTaskDialog(
    editedTask: Task,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    var editedText by remember {
        mutableStateOf(editedTask.description)
    }
    val firstCheckboxVal = editedTask.isDone
    var isDone by remember {
        mutableStateOf(firstCheckboxVal)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Edytuj zadanie " + editedTask.name) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Divider()
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    label = { Text("Description") },
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Text
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
                Divider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Text(text = "Czy wykonano: ")
                    Checkbox(checked = isDone, onCheckedChange = {
                        isDone = it
                    })
                }
                Divider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Usuń to zadanie: ",
                        color = Color.Red
                    )
                    Icon(
                        painter = painterResource(id = R.drawable.baseline_delete_forever_24),
                        contentDescription = "Delete task",
                        modifier = Modifier
                            .height(24.dp)
                            .clickable {
                                val database = DatabaseProvider.getInstance(context)
                                GlobalScope.launch(Dispatchers.IO) {
                                    database
                                        .taskDao()
                                        .deleteTask(editedTask)
                                }
                                onDismiss()
                            }
                    )
                }
                Divider()
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    println("id: " + editedTask.id)
                    val editedTask = editedTask.copy(description = editedText, isDone = isDone)
                    onSave(editedTask)
                    onDismiss()
                }
            ) {
                Text(text = "Zapisz")
            }
        },
        dismissButton = {
            // You can add a dismiss button here if needed
            // For example:
            Button(
                onClick = {
                    onDismiss()
                }
            ) {
                Text(text = "Anuluj")
            }
        }
    )
}