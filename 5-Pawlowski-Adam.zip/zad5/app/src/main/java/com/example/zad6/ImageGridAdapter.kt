package com.example.zad6

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageView
import com.bumptech.glide.Glide

class ImageGridAdapter(private val images: List<Uri>, private val screenWidth: Int, private val listener: AuthorAvatarFragment.OnImageClickListener) : RecyclerView.Adapter<ImageGridAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.gridImageView)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.grid_item, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemView.setOnClickListener {
            if (position != RecyclerView.NO_POSITION) {
                listener.onImageClick(images[position])
            }
        }
        holder.itemView.setOnLongClickListener {
            if (position != RecyclerView.NO_POSITION) {
                listener.onLongImageClick(images[position])
            }
            true
        }
        Glide.with(holder.itemView.context).load(images[position]).into(holder.imageView)
        val layoutParams = holder.imageView.layoutParams
        layoutParams.width = screenWidth / 2 - (8 * 2)
        holder.imageView.layoutParams = layoutParams
    }

    override fun getItemCount() = images.size
}
