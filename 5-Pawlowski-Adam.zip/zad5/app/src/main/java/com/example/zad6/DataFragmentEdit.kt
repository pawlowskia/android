package com.example.zad6

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.navigation.fragment.findNavController

class DataFragmentEdit : Fragment() {
    private lateinit var dataRepo: MyRepository
    private var selectedImagePath: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_data_edit, container, false)
        dataRepo = MyRepository.getinstance(requireContext())
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val editTextDate: EditText = view.findViewById(R.id.editTextDate)
        val editTextTime: EditText = view.findViewById(R.id.editTextTime)
        val editTextTitle: EditText = view.findViewById(R.id.editTextTitle)
        val checkboxStream: CheckBox = view.findViewById(R.id.checkboxStream)
        val exitButton: Button = view.findViewById(R.id.exitButton)
        val saveButton: Button = view.findViewById(R.id.saveButton)


        val data = requireContext().getSharedPreferences("data", Context.MODE_PRIVATE)
        dataRepo = MyRepository.getinstance(requireContext())
        val id = data.getLong("id", -1)
        val dataItem : DBItem = if(id.toInt() == -1)
            DBItem()
        else
            dataRepo.getDataById(id) ?: DBItem()
        editTextDate.setText(dataItem.name)
        editTextTime.setText(dataItem.nip)
        editTextTitle.setText(dataItem.tel)
        checkboxStream.isChecked = dataItem.vat

        if (dataItem.imagePath.isNotEmpty()) {
            selectedImagePath = dataItem.imagePath
        }
        exitButton.setOnClickListener {
            findNavController().navigate(R.id.list2Fragment)
        }
        saveButton.setOnClickListener {
            dataItem.name = editTextDate.text.toString().takeIf { it.isNotEmpty() } ?: ""
            dataItem.nip = editTextTime.text.toString().takeIf { it.isNotEmpty() } ?: ""
            dataItem.tel = editTextTitle.text.toString().takeIf { it.isNotEmpty() } ?: ""
            dataItem.vat = checkboxStream.isChecked
            if (id.toInt() ==-1)
                dataRepo.addItem(dataItem)
            else
                dataRepo.updateItem(dataItem)
            findNavController().navigate(R.id.list2Fragment)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 123 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                val imageUri = uri.toString()
                selectedImagePath = imageUri
            }
        }
    }

}