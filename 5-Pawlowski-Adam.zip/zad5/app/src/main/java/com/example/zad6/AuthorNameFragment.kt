package com.example.zad6

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText

class AuthorNameFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_author_name, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val nameInput = view.findViewById<EditText>(R.id.editTextText)
        val helloInput = view.findViewById<EditText>(R.id.editTextText2)

        val sharedPreferences = requireContext().getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        val savedName = sharedPreferences.getString("name", "Żółte słońce")
        val savedHello = sharedPreferences.getString("hello", "Witaj w aplikacji!")

        nameInput.setText(savedName)
        helloInput.setText(savedHello)

        nameInput.addTextChangedListener(createTextWatcher(nameInput, "name"))
        helloInput.addTextChangedListener(createTextWatcher(helloInput, "hello"))
    }

    private fun createTextWatcher(editText: EditText, key: String): TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val data = requireContext().getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
                data.edit().putString(key, editText.text.toString()).apply()
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            AuthorNameFragment().apply {
            }
    }
}