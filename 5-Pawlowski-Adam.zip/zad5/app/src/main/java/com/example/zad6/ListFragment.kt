package com.example.zad6

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.zad6.databinding.FragmentListBinding
import com.example.zad6.databinding.ListRowBinding


class ListFragment : Fragment() {
    private lateinit var binding: FragmentListBinding
    private lateinit var dataRepo: MyRepository
    lateinit var adapter : MyAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        dataRepo = MyRepository.getinstance(requireContext())
        adapter = MyAdapter(onItemAction)
        adapter.submitList(dataRepo.getData())
        binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recView = binding.recyclerView
        recView.layoutManager = LinearLayoutManager(requireContext())
        recView.adapter = adapter
        val fab = binding.floatingActionButton
        fab.setOnClickListener {
            val data = requireContext().getSharedPreferences("data", Context.MODE_PRIVATE)
            data.edit().putLong("id", -1).apply()
            findNavController().navigate(R.id.dataFragmentEdit)
        }
    }

    companion object{
        private val DiffCallback = object : DiffUtil.ItemCallback<DBItem>(){
            override fun areItemsTheSame(oldItem: DBItem, newItem: DBItem): Boolean {
                return oldItem.id == newItem.id
            }

            @SuppressLint("DiffUtilEquals")
            override fun areContentsTheSame(oldItem: DBItem, newItem: DBItem): Boolean {
                return oldItem == newItem
            }
        }
    }
    var onItemAction: (item: DBItem, action:Int) -> Unit = { item, action ->
        when (action){
            1-> {
                val data = requireContext().getSharedPreferences("data", Context.MODE_PRIVATE)
                data.edit().putLong("id", item.id.toLong()).apply()
                findNavController().navigate(R.id.dataFragment)
            }
            2 ->{
                dataRepo.deleteItem(item)
                adapter.submitList(dataRepo.getData())
            }
        }
    }
    inner class MyAdapter(private val onItemAction: (item:DBItem, action:Int)->Unit): ListAdapter<DBItem, MyAdapter.MyViewHolder>(
    DiffCallback){

        inner class MyViewHolder(viewBinding: ListRowBinding) : RecyclerView.ViewHolder(viewBinding.root)
        {
            val dateAndTime: TextView = viewBinding.dateTimeTextView
            val iconImageView: ImageView = viewBinding.iconImageView
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val viewBinding = ListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            val holder = MyViewHolder(viewBinding)
            holder.itemView.setOnClickListener {
                val position = holder.adapterPosition
                onItemAction(getItem(position),1)
            }
            holder.itemView.setOnLongClickListener{
                val position = holder.adapterPosition
                onItemAction(getItem(position),2)
                true
            }
            return holder
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            val item = getItem(position)
            val dateAndTime = "${item.name}"
            holder.dateAndTime.text = dateAndTime
            if (item.imagePath.isNotEmpty()) {
                context?.let { Glide.with(it).load(item.imagePath).into(holder.iconImageView) }
            } else {
                holder.iconImageView.visibility = View.GONE
            }
        }
    }
}
