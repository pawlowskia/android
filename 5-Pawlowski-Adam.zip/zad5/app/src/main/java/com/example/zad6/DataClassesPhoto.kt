package com.example.zad6

import android.content.Context
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Database
import androidx.room.Delete
import androidx.room.OnConflictStrategy
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase
import androidx.room.Update

@Entity(tableName = "photo_item_table")
class DBItemPhoto() {
    @PrimaryKey(autoGenerate = true)
    var id = 0
    var imagePath: String = ""
    constructor(
        imagePath: String
    ) : this() {
        this.imagePath = imagePath
    }
}

@Dao
interface MyDaoPhoto {
    @Query("SELECT * FROM photo_item_table ORDER BY id ASC")
    fun getAllData(): MutableList<DBItemPhoto>?
    @Query("DELETE FROM photo_item_table")
    fun deleteAll()
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(item: DBItemPhoto?) : Long
    @Delete
    fun delete(item: DBItemPhoto?) : Int
    @Query("SELECT * FROM photo_item_table WHERE id = :itemId")
    fun getItemById(itemId: Long): DBItemPhoto?
    @Update
    fun update(item: DBItemPhoto): Int
    @Query("DELETE FROM photo_item_table WHERE imagePath = :imagePath")
    fun deleteByImagePath(imagePath: String): Int
}

@Database(entities = [DBItemPhoto::class], version = 1)
abstract class MyDBPhoto :RoomDatabase() {
    abstract fun myDao(): MyDaoPhoto?
    companion object {
        private var DB_INSTANCE: MyDBPhoto? = null
        @Synchronized
        open fun getDatabase(context: Context): MyDBPhoto? {
            if (DB_INSTANCE == null) {
                DB_INSTANCE = databaseBuilder(context.applicationContext,
                    MyDBPhoto::class.java,
                    "photo_item_database")
                    .allowMainThreadQueries()
                    .build()
            }
            return DB_INSTANCE
        }
    }
}

class MyRepositoryPhoto(context: Context) {
    private var dataList: MutableList<DBItemPhoto>? = null
    private var myDao: MyDaoPhoto
    private var db: MyDBPhoto

    init {
        db = MyDBPhoto.getDatabase(context)!!
        myDao = db.myDao()!!
        addItem(DBItemPhoto("android.resource://com.example.zad6/drawable/red"))
        addItem(DBItemPhoto("android.resource://com.example.zad6/drawable/blue"))
        addItem(DBItemPhoto("android.resource://com.example.zad6/drawable/green"))
    }

    fun getData(): MutableList<DBItemPhoto>? {
        dataList = myDao.getAllData()
        return dataList
    }
    fun addItem(item: DBItemPhoto?) : Boolean {
        return myDao.insert(item) >= 0
    }
    fun deleteItem(item: DBItemPhoto?) : Boolean {
        return myDao.delete(item) > 0
    }
    fun deleteItemByImagePath(imagePath: String): Boolean {
        return myDao.deleteByImagePath(imagePath) > 0
    }
    fun getDataById(id: Long): DBItemPhoto?{
        return myDao.getItemById(id)
    }
    fun updateItem(item: DBItemPhoto): Boolean {
        return myDao.update(item) > 0
    }

    companion object{
        private var R_INSTANCE: MyRepositoryPhoto? = null
        fun getinstance(context: Context): MyRepositoryPhoto {
            if (R_INSTANCE == null){
                R_INSTANCE = MyRepositoryPhoto(context)
            }
            return R_INSTANCE as MyRepositoryPhoto
        }
    }
}