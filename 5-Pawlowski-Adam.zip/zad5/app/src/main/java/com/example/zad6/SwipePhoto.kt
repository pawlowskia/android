package com.example.zad6

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.floatingactionbutton.FloatingActionButton

class SwipePhoto : Fragment() {
    private lateinit var myRepositoryPhoto: MyRepositoryPhoto
    private var images = ArrayList<Uri>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        myRepositoryPhoto = MyRepositoryPhoto.getinstance(requireContext())
        return inflater.inflate(R.layout.fragment_swipe, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadImagesFromDatabase()
        val viewPager: ViewPager2 = view.findViewById(R.id.viewPager)
        viewPager.adapter = ViewPagerAdapterImage(this, images)
        var startingIndex = arguments?.getInt("startingIndex") ?: 0
        if (startingIndex>=images.size)
            startingIndex = images.size-1
        viewPager.setCurrentItem(startingIndex, false)
        val btnConfirmImage: FloatingActionButton = view.findViewById(R.id.fab)
        btnConfirmImage.setOnClickListener {
            val currentPosition = viewPager.currentItem
            if (currentPosition < images.size) {
                val selectedImageUri = images[currentPosition]
                confirmImage(selectedImageUri)
            }
        }
    }
    private fun loadImagesFromDatabase() {
        val imageList = myRepositoryPhoto.getData()
        images = ArrayList<Uri>()
        imageList?.forEach { dbItem ->
            images.add(Uri.parse(dbItem.imagePath))
        }
    }
    private fun confirmImage(imageUri: Uri) {
        val data = requireContext().getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        data.edit().putString("image", imageUri.toString()).apply()
        findNavController().navigateUp()
    }
}

class ViewPagerAdapterImage(fragment: Fragment, private val imageResIds: List<Uri>) : FragmentStateAdapter(fragment) {

    override fun getItemCount(): Int = imageResIds.size

    override fun createFragment(position: Int): Fragment {
        val fragment = ImageFragment()
        val bundle = Bundle()
        bundle.putString("imageUri", imageResIds[position].toString())
        fragment.arguments = bundle
        return fragment
    }
}


