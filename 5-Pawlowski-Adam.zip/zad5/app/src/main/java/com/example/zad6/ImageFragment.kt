package com.example.zad6

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import androidx.fragment.app.Fragment

class ImageFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_image, container, false)
        val imageView: ImageView = view.findViewById(R.id.imageView)
        val imageResId = arguments?.getString("imageUri") ?: R.drawable.screenshot
        Glide.with(imageView.context).load(imageResId).into(imageView)
        return view
    }
}