package com.example.zad6

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.net.Uri
import androidx.core.content.ContextCompat
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AuthorAvatarFragment : Fragment() {
    private var counter = 0
    private lateinit var recyclerView: RecyclerView
    private lateinit var imageAdapter: ImageGridAdapter
    private var images = ArrayList<Uri>()
    private lateinit var currentPhotoPath: String
    private lateinit var myRepositoryPhoto: MyRepositoryPhoto

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        counter = 0
        myRepositoryPhoto = MyRepositoryPhoto.getinstance(requireContext())
        return inflater.inflate(R.layout.fragment_author_avatar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2)
        val displayMetrics = Resources.getSystem().displayMetrics
        val screenWidth = displayMetrics.widthPixels
        loadImagesFromDatabase()
        val imageClickListener = object : OnImageClickListener {
            override fun onImageClick(imageUri: Uri) {
                val position = images.indexOf(imageUri)
                if (position != -1) {
                    val bundle = Bundle()
                    bundle.putInt("startingIndex", position)
                    findNavController().navigate(R.id.swipePhoto, bundle)
                }
            }
            override fun onLongImageClick(imageUri: Uri) {
                TODO("Not yet implemented")
            }
        }
        imageAdapter = ImageGridAdapter(images, screenWidth, imageClickListener)
        recyclerView.adapter = imageAdapter

        val fab: FloatingActionButton = view.findViewById(R.id.floatingActionButton)
        fab.setOnClickListener {
            aparatGaleria()
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                openCamera()
            }
        }
    }
    private fun loadImagesFromDatabase() {
        val imageList = myRepositoryPhoto.getData()
        images = ArrayList()
        imageList?.forEach { dbItem ->
            images.add(Uri.parse(dbItem.imagePath))
        }
    }

    private fun aparatGaleria() {
        val options = arrayOf("Aparat", "Galeria")
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Zdjęcie")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        openCamera()
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 1001)
                    }
                }
                1 -> openGallery()
            }
        }
        builder.show()
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, 1002)
    }

    private fun openCamera(){
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val photoUri: Uri = FileProvider.getUriForFile(
            requireContext(),
            "com.example.yourapplication.fileprovider",
            image()
        )
        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
        startActivityForResult(intent, 1001)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                1001 -> {
                    val imageUri = Uri.fromFile(File(currentPhotoPath))
                    handleImageUri(imageUri)
                }
                1002 -> {
                    val imageUri = data?.data
                    imageUri?.let { handleImageUri(it) }
                }
            }
        }
    }
    @SuppressLint("NotifyDataSetChanged")
    private fun handleImageUri(imageUri: Uri) {
        images.add(imageUri)
        imageAdapter.notifyDataSetChanged()
        myRepositoryPhoto.addItem(DBItemPhoto(imageUri.toString()))
    }
    companion object {
        @JvmStatic
        fun newInstance() = AuthorAvatarFragment()
    }

    private fun image(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }
    interface OnImageClickListener {
        fun onImageClick(imageUri: Uri)
        fun onLongImageClick(imageUri: Uri)
    }
}