package com.example.zad6

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide

class PrimaryFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_primary, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val data = requireContext().getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        val imageView = view.findViewById<ImageView>(R.id.imageView)
        val avatarResult = data.getString("image", "")
        if(avatarResult != ""){
            try {
                Glide.with(imageView.context).load(avatarResult).into(imageView)
            }
            finally{
                imageView.setImageResource(R.drawable.screenshot)
            }
        }
        else{
            imageView.setImageResource(R.drawable.screenshot)
        }
        val nameText = view.findViewById<TextView>(R.id.authorNameText)
        val nameResult = data.getString("name", "Żółte słońce")
        nameText.text = nameResult

        val helloText = view.findViewById<TextView>(R.id.helloText)
        val helloResult = data.getString("hello", "Witaj w aplikacji!")
        helloText.text = helloResult
    }
}