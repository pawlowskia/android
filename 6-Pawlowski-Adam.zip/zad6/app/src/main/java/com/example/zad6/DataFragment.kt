package com.example.zad6

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide


class DataFragment : Fragment() {
    private lateinit var dataRepo: MyRepository

    @SuppressLint("SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_data, container, false)

        val textViewDate: TextView = view.findViewById(R.id.textViewDate)
        val textViewTime: TextView = view.findViewById(R.id.textViewTime)
        val textViewTitle: TextView = view.findViewById(R.id.textViewTitle)
        val checkboxStream: CheckBox = view.findViewById(R.id.checkboxStream)
        val editButton: Button = view.findViewById(R.id.buttonEdit)
        val backButton: Button = view.findViewById(R.id.buttonBack)

        val data = requireContext().getSharedPreferences("data", Context.MODE_PRIVATE)
        dataRepo = MyRepository.getinstance(requireContext())
        val id = data.getLong("id", 0)
        val dataItem = dataRepo.getDataById(id)

        if (dataItem != null) {
            textViewDate.text = "NIP: ${dataItem.nip}"
            textViewTime.text = "Nr. telefonu: ${dataItem.tel}"
            textViewTitle.text = "Nazwa firmy: ${dataItem.name}"
            checkboxStream.isChecked = dataItem.vat
            checkboxStream.isEnabled = true
        }

        editButton.setOnClickListener {
            findNavController().navigate(R.id.dataFragmentEdit)
        }
        backButton.setOnClickListener {
//            findNavController().navigate(R.id.action_dataFragment_to_listFragment)
        }

        return view
    }
}
